#include <stdlib.h>
#include "fmpz.h"
#include "fq_nmod.h"
#include "fq_nmod_poly.h"
#include "profiler.h"

#define nalgs 2
#define ncases 10
#define cpumin 2

int
main(int argc, char** argv)
{
    double s[nalgs];

    int c, n, lenf, leng, ext, reps = 0;
    ulong p;
    fmpz_t temp;
    fq_nmod_poly_t f, g, h;
    fq_nmod_ctx_t ctx;

    FLINT_TEST_INIT(state);

    p = strtoull(argv[1], NULL, 10);

    fmpz_init(temp);

    fmpz_set_str(temp, argv[2], 10);
    ext = fmpz_get_si(temp);

    lenf = atol(argv[3]);
    leng = atol(argv[4]);

    fq_nmod_ctx_init_ui(ctx, p, ext, "a");

    fq_nmod_poly_init(f, ctx);
    fq_nmod_poly_init(g, ctx);
    fq_nmod_poly_init(h, ctx);

    for (c = 0; c < nalgs; c++)
    {
        s[c] = 0.0;
    }

    for (n = 0; n < ncases; n++)
    {
        double t[nalgs];
        int l, loops = 1;

        /*
           Construct random elements of fq
        */
        {
            fq_nmod_poly_randtest_monic(f, state, lenf, ctx);
            fq_nmod_poly_randtest_monic(g, state, leng, ctx);
        }

    loop:
        t[0] = 0.0;
        init_clock(0);
        prof_start();
        for (l = 0; l < loops; l++)
        {
            fq_nmod_poly_mul(h, f, g, ctx);
        }
        prof_stop();
        t[0] += get_clock(0);

        t[1] = 0.0;
        init_clock(0);
        prof_start();
        for (l = 0; l < loops; l++)
        {
            fq_nmod_poly_mul_univariate(h, f, g, ctx);
        }
        prof_stop();
        t[1] += get_clock(0);

        for (c = 0; c < nalgs; c++)
            if (t[c] * FLINT_CLOCK_SCALE_FACTOR <= cpumin)
            {
                loops *= 10;
                goto loop;
            }

        for (c = 0; c < nalgs; c++)
            s[c] += t[c];
        reps += loops;
    }

    for (c = 0; c < nalgs; c++)
    {
        flint_printf("%20f ", s[c] / (double) reps);
        fflush(stdout);
    }
    printf("\n");

    fq_nmod_poly_clear(h, ctx);
    fq_nmod_poly_clear(f, ctx);
    fq_nmod_poly_clear(g, ctx);
    fq_nmod_ctx_clear(ctx);
    fmpz_clear(temp);

    FLINT_TEST_CLEAR(state);

    return 0;
}
