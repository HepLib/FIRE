.. _contributors:

**Contributors**
===============================================================================

Contributors
-------------------------------------------------------------------------------

FLINT has only been possible due to an extraordinary number of high quality
contributions from a vast array of people.

A complete list of contributors is available on the FLINT website at:
https://flintlib.org/authors.html

If you believe your name is missing from this list, please contact us
immediately on the ``flint-devel`` list. The list is updated at the time of
each new release of FLINT.

