.. _index-rationals:

**Rational numbers** : *detailed table of contents*
====================================================

.. only:: html

    .. toctree::
       :maxdepth: 3

       fmpq.rst
       fmpq_vec.rst
       fmpq_mat.rst
       fmpq_poly.rst
       fmpq_mpoly_factor.rst
       fmpq_mpoly.rst
       fmpz_poly_q.rst
