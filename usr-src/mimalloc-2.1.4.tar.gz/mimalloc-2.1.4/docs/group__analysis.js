var group__analysis =
[
    [ "mi_heap_area_t", "group__analysis.html#structmi__heap__area__t", [
      [ "block_size", "group__analysis.html#a332a6c14d736a99699d5453a1cb04b41", null ],
      [ "blocks", "group__analysis.html#ae0085e6e1cf059a4eb7767e30e9991b8", null ],
      [ "committed", "group__analysis.html#ab47526df656d8837ec3e97f11b83f835", null ],
      [ "reserved", "group__analysis.html#ae848a3e6840414891035423948ca0383", null ],
      [ "used", "group__analysis.html#ab820302c5cd0df133eb8e51650a008b4", null ]
    ] ],
    [ "mi_block_visit_fun", "group__analysis.html#gadfa01e2900f0e5d515ad5506b26f6d65", null ],
    [ "mi_check_owned", "group__analysis.html#ga628c237489c2679af84a4d0d143b3dd5", null ],
    [ "mi_heap_check_owned", "group__analysis.html#ga0d67c1789faaa15ff366c024fcaf6377", null ],
    [ "mi_heap_contains_block", "group__analysis.html#gaa862aa8ed8d57d84cae41fc1022d71af", null ],
    [ "mi_heap_visit_blocks", "group__analysis.html#ga70c46687dc6e9dc98b232b02646f8bed", null ]
];