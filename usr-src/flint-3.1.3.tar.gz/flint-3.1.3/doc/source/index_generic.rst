.. _index-generic:

**Generic rings** : *detailed table of contents*
=================================================================

.. only:: html

    .. toctree::
       :maxdepth: 3

       gr.rst
       gr_implementing.rst
       gr_domains.rst
       gr_special.rst
       gr_vec.rst
       gr_mat.rst
       gr_poly.rst
       gr_mpoly.rst

